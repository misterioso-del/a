# Bot-Whitelist
 
### ⚙️ Configure .env rename .env

```bash
TOKEN= 
```
